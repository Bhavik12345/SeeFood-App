package ceg4110.seefood;


import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ConnectException;
import java.net.Socket;
import java.util.ArrayList;

import result.Result;


public class GalleryActivity extends AppCompatActivity {


    ScrollView scrollView;
    static int idRow[];
    ArrayList<Result> listOfImages;
    static float GALLERY_SIZE = 300;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);

        Bundle receiveArgs = getIntent().getExtras();
        GALLERY_SIZE = receiveArgs.getInt("GALLERY_SIZE");

        scrollView = (ScrollView) findViewById(R.id.scrollView);

        new MyAsyncTask().execute();
    }

    public void addImages() throws IOException {

        int imageCounter = 0;
        int size = listOfImages.size();

        for(int i = imageCounter/3; imageCounter<size;i = imageCounter/3) {

            LinearLayout row = (LinearLayout) findViewById(idRow[i]);

            ImageView imagView = (ImageView) ((FrameLayout) row.getChildAt(imageCounter%3)).getChildAt(1);
            ImageView result = (ImageView) ((FrameLayout) row.getChildAt(imageCounter%3)).getChildAt(2);

            Result imgData = listOfImages.get(imageCounter++);
            Bitmap img = BitmapFactory.decodeByteArray(imgData.getImage(), 0, imgData.getImage().length);
            imagView.setImageBitmap(img);
            result.setBackgroundResource(imgData.getFood() == 1 ? R.drawable.checkmark : R.drawable.x);

        }

        LinearLayout lastRow = (LinearLayout) findViewById(idRow[imageCounter/3]);
        if(imageCounter%3 == 0){
            lastRow.removeAllViews();
        } else if(imageCounter%3 == 1) {
            ((FrameLayout)(lastRow.getChildAt(1))).removeAllViews();
            ((FrameLayout)(lastRow.getChildAt(2))).removeAllViews();
        }else if(imageCounter%3 == 2) {
            ((FrameLayout)(lastRow.getChildAt(2))).removeAllViews();
        }

    }

    class MyAsyncTask extends AsyncTask<Void,Void,Integer> {

        private Socket socket = null;
        private ObjectOutputStream out = null;
        private ObjectInputStream in = null;


        protected Integer doInBackground(Void... voids) {
            try {
                gallery();
                endConnection();
                return 1;
            } catch (IOException e) {
                return -1;
            } catch (ClassNotFoundException e) {
                return -1;
            }
        }

        protected void onPostExecute(Integer result) {

            try {
                if(result == 1)
                    addImages();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }




        private void gallery() throws IOException, ClassNotFoundException {

            listOfImages = getPictArrayList();

        }

        private ArrayList<Result> getPictArrayList() throws IOException, ClassNotFoundException {

            ArrayList<Result> al = null;

            try {

                out.writeInt(2);
                out.flush();

                al = (ArrayList<Result>) in.readObject();

            } catch (ConnectException ex) {

            }

            return al;

        }
        private void endConnection() throws IOException {

            if (socket != null) {
                out.close();
                out = null;
                in.close();
                in = null;
                socket.close();
                socket = null;
            }

        }

    }

}


